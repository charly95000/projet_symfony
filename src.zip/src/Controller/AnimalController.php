<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Animal;
use App\Repository\AnimalRepository;
use Symfony\Component\HttpFoundation\Request;
use App\Form\AnimalType;
use Symfony\Component\HttpFoundation\File\Exception\FileException;
use Symfony\Component\HttpFoundation\File\UploadedFile;


#[Route('/animal')]
class AnimalController extends AbstractController
{
    #[Route('/', name: 'animal')]
    public function index(AnimalRepository $animalRepository): Response
    {
        return $this->render('animal/index.html.twig', [
            'animaux' => $animalRepository->findAll(),
        ]);
    }

    #[Route('/add', name :"add")]
    public function add() : Response
    {
        $animal = new Animal;
        $animal->setNom('Charly');
        $animal->setPhoto('photo');
        $em = $this->getDoctrine()->getManager();
        $em->persist($animal);
        $em->flush();
        return $this->redirectToRoute('animal');
    }

    #[Route('/add2', name : "add2")]
    public function addWithForm(Request $request) : Response
    {
        $animal = new Animal;
        $form = $this->createForm(AnimalType::class, $animal);
        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){
            $photoFile = $form->get('image')->getData();
            $photoFilename = uniqid().'.'.$photoFile->guessExtension();
            try{
                $photoFile->move(
                    $this->getParameter('images_animaux_directory'),
                    $photoFilename
                );
            }catch (FileException $e){

            }
            $animal->setImage($photoFilename);
            $em = $this->getDoctrine()->getManager();
            $em->persist($animal);
            $em->flush();
            return $this->redirectToRoute('animal');
        }

        return $this->render('animal/add.html.twig', [
            'form' => $form->createView()
        ]);
    }

    #[Route('/update/{id}', name : "update2")]
    public function update(Request $request, Animal $animal) : Response
    {
        $form = $this->createForm(AnimalType::class, $animal);
        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){
            $em = $this->getDoctrine()->getManager();
            $em->persist($animal);
            $em->flush();
            return $this->redirectToRoute('animal');
        }
        return $this->render('animal/add.html.twig', [
            'form' => $form->createView()
        ]);
    }

    #[Route('/{id}', name : "one2")]
    public function one(Request $request, Animal $animal) : Response
    {
        return $this->render('animal/one.html.twig', [
            'animal' => $animal,
        ]);
    }

    #[Route("/delete/{id}", name : "delete")]
    public function delete(Request $request, Animal $animal) : Response
    {
        $entityManager = $this->getDoctrine()->getManager();
        $entityManager->remove($animal);
        $entityManager->flush();
        return $this->redirectToRoute('animal');
    }
}
